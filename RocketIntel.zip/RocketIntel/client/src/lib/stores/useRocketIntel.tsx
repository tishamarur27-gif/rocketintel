import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type RocketModel = {
  id: string;
  name: string;
  type: string;
  height: number;
  diameter: number;
  mass: number;
  payload: number;
  thrust: number;
  fuelCapacity: number;
  color: string;
};

export type MissionPhase = 
  | "pre-launch" 
  | "ignition" 
  | "liftoff" 
  | "max-q" 
  | "stage-separation" 
  | "orbit-insertion" 
  | "completed"
  | "failed";

export type TelemetryData = {
  speed: number;
  altitude: number;
  fuel: number;
  temperature: number;
  pressure: number;
  acceleration: number;
  timestamp: number;
};

export type AnomalyStatus = {
  overall: "nominal" | "warning" | "critical";
  engine: "nominal" | "warning" | "critical";
  fuel: "nominal" | "warning" | "critical";
  guidance: "nominal" | "warning" | "critical";
  temperature: "nominal" | "warning" | "critical";
};

export type AIAnalysis = {
  overallRisk: "low" | "medium" | "high" | "critical";
  predictions: Array<{
    system: string;
    risk: "low" | "medium" | "high" | "critical";
    prediction: string;
    confidence: number;
  }>;
  recommendations: string[];
};

interface RocketIntelState {
  selectedRocket: RocketModel | null;
  missionPhase: MissionPhase;
  telemetry: TelemetryData;
  anomalyStatus: AnomalyStatus;
  aiAnalysis: AIAnalysis | null;
  isSimulating: boolean;
  simulationTime: number;
  trajectoryPoints: Array<{ x: number; y: number; z: number }>;
  telemetryHistory: TelemetryData[];
  
  setSelectedRocket: (rocket: RocketModel) => void;
  setMissionPhase: (phase: MissionPhase) => void;
  updateTelemetry: (data: Partial<TelemetryData>) => void;
  updateAnomalyStatus: (status: Partial<AnomalyStatus>) => void;
  setAIAnalysis: (analysis: AIAnalysis) => void;
  startSimulation: () => void;
  stopSimulation: () => void;
  resetSimulation: () => void;
  updateSimulationTime: (time: number) => void;
  addTrajectoryPoint: (point: { x: number; y: number; z: number }) => void;
  clearTrajectory: () => void;
  addTelemetryToHistory: (data: TelemetryData) => void;
}

const ROCKET_MODELS: RocketModel[] = [
  {
    id: "falcon-9",
    name: "Falcon 9",
    type: "Orbital Launch Vehicle",
    height: 70,
    diameter: 3.7,
    mass: 549054,
    payload: 22800,
    thrust: 7607000,
    fuelCapacity: 100,
    color: "#ffffff"
  },
  {
    id: "starship",
    name: "Starship",
    type: "Super Heavy-Lift Launch Vehicle",
    height: 120,
    diameter: 9,
    mass: 5000000,
    payload: 100000,
    thrust: 72000000,
    fuelCapacity: 100,
    color: "#c0c0c0"
  },
  {
    id: "atlas-v",
    name: "Atlas V",
    type: "Expendable Launch System",
    height: 58,
    diameter: 3.8,
    mass: 334500,
    payload: 18814,
    thrust: 4152000,
    fuelCapacity: 100,
    color: "#ff6b35"
  }
];

export const useRocketIntel = create<RocketIntelState>()(
  subscribeWithSelector((set, get) => ({
    selectedRocket: ROCKET_MODELS[0],
    missionPhase: "pre-launch",
    telemetry: {
      speed: 0,
      altitude: 0,
      fuel: 100,
      temperature: 20,
      pressure: 101.3,
      acceleration: 0,
      timestamp: 0
    },
    anomalyStatus: {
      overall: "nominal",
      engine: "nominal",
      fuel: "nominal",
      guidance: "nominal",
      temperature: "nominal"
    },
    aiAnalysis: null,
    isSimulating: false,
    simulationTime: 0,
    trajectoryPoints: [],
    telemetryHistory: [],
    
    setSelectedRocket: (rocket) => set({ selectedRocket: rocket }),
    
    setMissionPhase: (phase) => set({ missionPhase: phase }),
    
    updateTelemetry: (data) => set((state) => ({
      telemetry: { ...state.telemetry, ...data }
    })),
    
    updateAnomalyStatus: (status) => set((state) => ({
      anomalyStatus: { ...state.anomalyStatus, ...status }
    })),
    
    setAIAnalysis: (analysis) => set({ aiAnalysis: analysis }),
    
    startSimulation: () => {
      set({ 
        isSimulating: true, 
        missionPhase: "ignition",
        simulationTime: 0,
        trajectoryPoints: [],
        telemetryHistory: [],
        aiAnalysis: null,
        telemetry: {
          speed: 0,
          altitude: 0,
          fuel: 100,
          temperature: 20,
          pressure: 101.3,
          acceleration: 0,
          timestamp: 0
        }
      });
    },
    
    stopSimulation: () => set({ isSimulating: false }),
    
    resetSimulation: () => set({
      isSimulating: false,
      missionPhase: "pre-launch",
      simulationTime: 0,
      trajectoryPoints: [],
      telemetryHistory: [],
      aiAnalysis: null,
      telemetry: {
        speed: 0,
        altitude: 0,
        fuel: 100,
        temperature: 20,
        pressure: 101.3,
        acceleration: 0,
        timestamp: 0
      },
      anomalyStatus: {
        overall: "nominal",
        engine: "nominal",
        fuel: "nominal",
        guidance: "nominal",
        temperature: "nominal"
      }
    }),
    
    updateSimulationTime: (time) => set({ simulationTime: time }),
    
    addTrajectoryPoint: (point) => set((state) => ({
      trajectoryPoints: [...state.trajectoryPoints, point]
    })),
    
    clearTrajectory: () => set({ trajectoryPoints: [] }),
    
    addTelemetryToHistory: (data) => set((state) => ({
      telemetryHistory: [...state.telemetryHistory, data]
    }))
  }))
);

export { ROCKET_MODELS };
