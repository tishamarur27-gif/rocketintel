import { useRocketIntel, ROCKET_MODELS } from "@/lib/stores/useRocketIntel";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Pause, RotateCcw } from "lucide-react";
import { useState } from "react";
import { MissionReportExport } from "./MissionReportExport";

export function MissionControl() {
  const { 
    selectedRocket, 
    setSelectedRocket, 
    isSimulating, 
    startSimulation, 
    stopSimulation, 
    resetSimulation,
    missionPhase 
  } = useRocketIntel();
  
  const [showRocketSelect, setShowRocketSelect] = useState(true);

  const handleStart = () => {
    startSimulation();
    setShowRocketSelect(false);
  };

  const handleStop = () => {
    stopSimulation();
  };

  const handleReset = () => {
    resetSimulation();
    setShowRocketSelect(true);
  };

  return (
    <div className="lg:absolute lg:top-4 lg:left-4 space-y-2 pointer-events-auto w-full lg:max-w-md">
      <Card className="bg-purple-950/95 border-purple-500/50 backdrop-blur-md shadow-2xl shadow-purple-500/20">
        <div className="p-3 md:p-4">
          <div className="flex items-center justify-between mb-3 md:mb-4">
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 animate-gradient">
                ROCKETINTEL
              </h1>
              <p className="text-[10px] md:text-xs text-gray-400 uppercase tracking-wider">
                Next-Gen Rocket Intelligence Platform
              </p>
            </div>
          </div>

          {!isSimulating && showRocketSelect && (
            <div className="mb-3 md:mb-4 space-y-2">
              <h3 className="text-xs md:text-sm font-bold text-cyan-300 uppercase tracking-wide mb-2 flex items-center gap-2">
                <span className="w-1 h-4 bg-gradient-to-b from-cyan-400 to-purple-400 rounded-full"></span>
                Select Mission Vehicle
              </h3>
              {ROCKET_MODELS.map((rocket) => (
                <button
                  key={rocket.id}
                  onClick={() => setSelectedRocket(rocket)}
                  className={`w-full text-left p-2 md:p-3 rounded-lg border transition-all transform hover:scale-[1.02] active:scale-[0.98] ${
                    selectedRocket?.id === rocket.id
                      ? "bg-gradient-to-br from-purple-600/40 to-cyan-600/20 border-purple-400 shadow-lg shadow-purple-500/30"
                      : "bg-black/40 border-cyan-500/30 hover:border-cyan-400 hover:shadow-lg hover:shadow-cyan-500/20"
                  }`}
                >
                  <div className="text-sm md:text-base font-bold text-white">{rocket.name}</div>
                  <div className="text-[10px] md:text-xs text-gray-400">{rocket.type}</div>
                  <div className="text-[10px] md:text-xs text-cyan-300 mt-1">
                    Height: {rocket.height}m | Payload: {(rocket.payload / 1000).toFixed(1)}t
                  </div>
                </button>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            {!isSimulating && (
              <Button
                onClick={handleStart}
                className="flex-1 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 text-white font-bold uppercase text-xs md:text-sm shadow-lg shadow-green-500/30 transform active:scale-95 transition-transform"
              >
                <Play className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
                <span className="hidden sm:inline">Launch</span>
                <span className="sm:hidden">Go</span>
              </Button>
            )}
            
            {isSimulating && (
              <Button
                onClick={handleStop}
                className="flex-1 bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-700 hover:to-yellow-600 text-white font-bold uppercase text-xs md:text-sm shadow-lg shadow-yellow-500/30 transform active:scale-95 transition-transform"
              >
                <Pause className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
                Pause
              </Button>
            )}
            
            <Button
              onClick={handleReset}
              className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 text-white font-bold uppercase text-xs md:text-sm shadow-lg shadow-red-500/30 transform active:scale-95 transition-transform px-2 md:px-4"
            >
              <RotateCcw className="w-3 h-3 md:w-4 md:h-4" />
            </Button>
          </div>

          {missionPhase === "completed" && (
            <div className="mt-4 p-3 bg-green-900/30 border border-green-500/50 rounded">
              <div className="text-sm font-bold text-green-400 uppercase mb-1">
                Mission Successful!
              </div>
              <p className="text-xs text-gray-300 mb-2">
                Orbit insertion achieved. All systems nominal.
              </p>
              <MissionReportExport />
            </div>
          )}
          
          {!isSimulating && missionPhase !== "pre-launch" && (
            <div className="mt-4">
              <MissionReportExport />
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
