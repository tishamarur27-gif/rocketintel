import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useRocketIntel } from "@/lib/stores/useRocketIntel";

export function Rocket3D() {
  const rocketRef = useRef<THREE.Group>(null);
  const { selectedRocket, isSimulating, simulationTime, missionPhase } = useRocketIntel();
  
  const rocketColor = useMemo(() => {
    return selectedRocket?.color || "#ffffff";
  }, [selectedRocket]);

  const scale = useMemo(() => {
    if (!selectedRocket) return 1;
    return selectedRocket.height / 70;
  }, [selectedRocket]);

  useFrame((state) => {
    if (!rocketRef.current) return;
    
    if (isSimulating) {
      const time = simulationTime;
      
      if (missionPhase === "pre-launch" || missionPhase === "ignition") {
        rocketRef.current.position.y = 0;
        rocketRef.current.rotation.z = 0;
      } else if (missionPhase === "liftoff" || missionPhase === "max-q") {
        const height = Math.min(time * 2, 50);
        rocketRef.current.position.y = height;
        rocketRef.current.rotation.z = Math.sin(time * 0.5) * 0.05;
      } else if (missionPhase === "stage-separation") {
        const height = 50 + (time - 25) * 3;
        rocketRef.current.position.y = Math.min(height, 100);
        rocketRef.current.rotation.z = Math.sin(time * 0.3) * 0.03;
      } else if (missionPhase === "orbit-insertion") {
        const height = 100 + (time - 40) * 2;
        rocketRef.current.position.y = Math.min(height, 150);
        rocketRef.current.rotation.z = (time - 40) * 0.02;
      }
    } else {
      rocketRef.current.rotation.y = state.clock.elapsedTime * 0.2;
    }
  });

  return (
    <group ref={rocketRef} position={[0, 0, 0]} scale={scale}>
      <group>
        <mesh castShadow position={[0, 3, 0]}>
          <coneGeometry args={[0.5, 2, 8]} />
          <meshStandardMaterial color={rocketColor} metalness={0.8} roughness={0.2} />
        </mesh>

        <mesh castShadow position={[0, 0, 0]}>
          <cylinderGeometry args={[0.5, 0.5, 6, 16]} />
          <meshStandardMaterial color={rocketColor} metalness={0.7} roughness={0.3} />
        </mesh>

        <mesh castShadow position={[0, 0.5, 0]}>
          <cylinderGeometry args={[0.52, 0.52, 1, 16]} />
          <meshStandardMaterial color="#1a1a1a" metalness={0.9} roughness={0.1} />
        </mesh>

        <mesh castShadow position={[-0.7, -2, 0]} rotation={[0, 0, Math.PI / 6]}>
          <coneGeometry args={[0.3, 1.5, 3]} />
          <meshStandardMaterial color="#ff4444" metalness={0.6} roughness={0.4} />
        </mesh>

        <mesh castShadow position={[0.7, -2, 0]} rotation={[0, 0, -Math.PI / 6]}>
          <coneGeometry args={[0.3, 1.5, 3]} />
          <meshStandardMaterial color="#ff4444" metalness={0.6} roughness={0.4} />
        </mesh>

        <mesh castShadow position={[0, -2, 0.7]} rotation={[Math.PI / 6, 0, 0]}>
          <coneGeometry args={[0.3, 1.5, 3]} />
          <meshStandardMaterial color="#ff4444" metalness={0.6} roughness={0.4} />
        </mesh>

        <mesh castShadow position={[0, -2, -0.7]} rotation={[-Math.PI / 6, 0, 0]}>
          <coneGeometry args={[0.3, 1.5, 3]} />
          <meshStandardMaterial color="#ff4444" metalness={0.6} roughness={0.4} />
        </mesh>

        {isSimulating && (missionPhase === "liftoff" || missionPhase === "max-q" || missionPhase === "stage-separation") && (
          <group position={[0, -3.5, 0]}>
            <pointLight color="#ff6600" intensity={5} distance={10} />
            
            <mesh position={[0, 0, 0]} rotation={[Math.PI, 0, 0]}>
              <coneGeometry args={[0.6, 2, 8]} />
              <meshBasicMaterial color="#ff6600" transparent opacity={0.8} />
            </mesh>
            
            <mesh position={[0, -1, 0]} rotation={[Math.PI, 0, 0]}>
              <coneGeometry args={[0.8, 2, 8]} />
              <meshBasicMaterial color="#ffaa00" transparent opacity={0.6} />
            </mesh>
            
            <mesh position={[0, -2, 0]} rotation={[Math.PI, 0, 0]}>
              <coneGeometry args={[1, 2, 8]} />
              <meshBasicMaterial color="#ffdd00" transparent opacity={0.4} />
            </mesh>
          </group>
        )}
      </group>
    </group>
  );
}
