import "@fontsource/inter";
import { RocketScene } from "./components/RocketScene";
import { MissionControl } from "./components/MissionControl";
import { TelemetryDashboard } from "./components/TelemetryDashboard";
import { AnomalyMonitor } from "./components/AnomalyMonitor";
import { MissionTimeline } from "./components/MissionTimeline";
import { AIAnalysisPanel } from "./components/AIAnalysisPanel";
import { ComparisonMode } from "./components/ComparisonMode";

function App() {
  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      <RocketScene />
      
      {/* Desktop Layout - Absolute positioned panels */}
      <div className="hidden lg:block absolute inset-0 pointer-events-none">
        <MissionControl />
        <TelemetryDashboard />
        <AnomalyMonitor />
        <MissionTimeline />
        <AIAnalysisPanel />
        <ComparisonMode />
      </div>
      
      {/* Mobile Layout - Stacked panels */}
      <div className="lg:hidden absolute inset-0 overflow-y-auto pointer-events-auto">
        <div className="flex flex-col gap-2 p-2">
          <MissionControl />
          <TelemetryDashboard />
          <MissionTimeline />
          <AnomalyMonitor />
        </div>
      </div>
    </div>
  );
}

export default App;
